export 'package:app1/screens/check_screen.dart';
export 'package:app1/screens/home_screen.dart';
export 'package:app1/screens/loading_screen.dart';
export 'package:app1/screens/login_screen.dart';
export 'package:app1/screens/registro_scren.dart';
export 'package:app1/screens/verification_screen.dart';
